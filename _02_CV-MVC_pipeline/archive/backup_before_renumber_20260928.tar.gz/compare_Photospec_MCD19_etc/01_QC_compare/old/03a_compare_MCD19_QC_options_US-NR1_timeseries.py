#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Author: Lewis Kunik - University of Utah
# Contact: lewis.kunik@utah.edu
#
# Created on Tue Oct 24 2023
#
#

#########################################
# Import packages
#########################################
#%%
# File system packages
import os  # operating system library
import sys
import glob
from pathlib import Path
import copy

# runtime packages
import warnings
# warnings.simplefilter(action='ignore', category=FutureWarning)
# warnings.simplefilter(action='ignore', category=DeprecationWarning)
import gc

# numerical/data management packages
import math
import numpy as np
import xarray as xr  # for multi dimensional data
# import rioxarray as rxr
import pandas as pd
import xesmf as xe
import struct
from rasterio.enums import Resampling
import geopandas as gpd

# Stats packages
from scipy.stats import linregress, spearmanr

# shapefile/geospatial packages

# time and date packages
import time
from datetime import datetime as dt  # date time library
from datetime import timedelta

# plotting packages
from matplotlib import pyplot as plt  # primary plotting module
from shapely.geometry import mapping
import cftime
import random
from matplotlib.patches import Patch
from matplotlib.dates import MonthLocator, DateFormatter
from matplotlib.ticker import MultipleLocator
import matplotlib.colors as mcolors
from matplotlib.ticker import FuncFormatter as FFmt  # need this for formatting plot ticks
import cartopy.crs as ccrs  #
from cartopy.io import img_tiles  # cartopy's implementation of webtiles
import cartopy.io.shapereader as shpreader
import cartopy.feature as cfeature


#########################################
# Define Global Filepaths
#########################################


#%%
site_name = 'US-NR1'

MODIS_tile = 'h09v04'

# Compare AOD and adjacency masks:
# 1: CloudFree_AllAOD_AllAdj
# 2: CloudFree_LowAOD_AllAdj

# 3: CloudFree_AllAOD_NotSurround
# 4: CloudFree_LowAOD_NotSurround

# 5: CloudFree_AllAOD_ClearAdj
# 6: CloudFree_LowAOD_ClearAdj

QC1_descr = "CloudFree_LowAOD_NotSurround"
QC2_descr = "CloudFree_LowAOD_NotSurround"
QC3_descr = "CloudFree_AllAOD_NotSurround"
QC4_descr = "CloudFree_AllAOD_NotSurround"


MCD19_dir_QC1 = f'/uufs/chpc.utah.edu/common/home/lin-group28/ltk/MODIS/MAIAC_MCD19A1/CV-MVC/1km_curv/pre-fill/VZA0-90/QCfilt_{QC1_descr}/{MODIS_tile}/'
MCD19_dir_QC2 = f'/uufs/chpc.utah.edu/common/home/lin-group28/ltk/MODIS/MAIAC_MCD19A1/CV-MVC/1km_curv/pre-fill/VZA0-90/QCfilt_{QC2_descr}/{MODIS_tile}/'
MCD19_dir_QC3 = f'/uufs/chpc.utah.edu/common/home/lin-group28/ltk/MODIS/MAIAC_MCD19A1/CV-MVC/1km_curv/pre-fill/VZA0-90/QCfilt_{QC3_descr}/{MODIS_tile}/'
MCD19_dir_QC4 = f'/uufs/chpc.utah.edu/common/home/lin-group28/ltk/MODIS/MAIAC_MCD19A1/CV-MVC/1km_curv/pre-fill/VZA0-90/QCfilt_{QC4_descr}/{MODIS_tile}/'

Photospec_dir = '/uufs/chpc.utah.edu/common/home/lin-group19/ltk/MODIS/CCI/data/PhotoSpec'
Photospec_file = os.path.join(Photospec_dir, f'PhotoSpec_{site_name}.csv')


MOD13_dir = '/uufs/chpc.utah.edu/common/home/lin-group23/ltk/MODIS/NDVI_EVI_MOD13A2/01d'
MCD43_dir = '/uufs/chpc.utah.edu/common/home/lin-group23/ltk/MODIS/Reflectance_MCD43A4/01d'

out_stats_dir = '/uufs/chpc.utah.edu/common/home/lin-group19/ltk/MODIS/CCI/output/CVMVC_QC_regression_stats/'
os.makedirs(out_stats_dir, exist_ok=True)

plot_dir = '/uufs/chpc.utah.edu/common/home/lin-group19/ltk/MODIS/CCI/plots/CVMVC_QC_regression_stats/'
os.makedirs(plot_dir, exist_ok=True)

#########################################
# Define Global functions
#########################################

def floor(value, decimal_digits):
  scale = (10**decimal_digits)
  return  np.floor(value * scale)/scale

def ceil(value, decimal_digits):
  scale = (10**decimal_digits)
  return  np.ceil(value * scale)/scale


def binary(num):
    return ''.join('{:0>8b}'.format(c) for c in struct.pack('!f', num))

binary_v = np.vectorize(binary)

def get_bits(str, start_bit, end_bit):
   str_split = [*str][start_bit:end_bit+1]
   return ''.join(str_split)

get_bits_v = np.vectorize(get_bits)

tanh_v = np.vectorize(np.tanh)

arccos_v = np.vectorize(np.arccos)

def rad_to_deg(rad):
   return rad*180/math.pi

def perdelta(start, end, delta):
    curr = start
    while curr < end:
        yield curr
        curr += delta

def td_min(td):
    return td.seconds//60

def td_sec(td):
    return td.seconds%60


def parse_timestamps_to_datetime_from_global_attrs(orbit_time_stamp):
    timestamps_raw = orbit_time_stamp.strip().split()
    orbit_times = []
    for timestamp in timestamps_raw:
        year = int(timestamp[0:4])
        julian_day = int(timestamp[4:7])
        hour = int(timestamp[7:9])
        minute = int(timestamp[9:11])
        dt_obj = dt(year, 1, 1) + timedelta(days=julian_day - 1, hours=hour, minutes=minute)
        orbit_times.append(dt_obj)
    # Convert to numpy.datetime64 array
    np_times = np.array(orbit_times, dtype='datetime64[m]')
    return np_times


def print_timestamp_satellite_info_from_global_attrs(orbit_time_stamp):
    timestamps_raw = orbit_time_stamp.strip().split()
    # Parse each timestamp
    orbit_times = []
    for timestamp in timestamps_raw:
        year = int(timestamp[0:4])
        julian_day = int(timestamp[4:7])
        hour = int(timestamp[7:9])
        minute = int(timestamp[9:11])
        if timestamp[11] == 'T':
            satellite = 'Terra'
        else:
            satellite = 'Aqua'

        dt_obj = dt(year, 1, 1) + timedelta(days=julian_day - 1, hours=hour, minutes=minute)
        orbit_times.append({'datetime': dt_obj, 'satellite': satellite})

    for i, orbit_info in enumerate(orbit_times):
        print(f"Orbit {i}: {orbit_info['datetime']} - Satellite: {orbit_info['satellite']}")



####################################
### Set up map parameters
####################################


#########################################
# Define Global Variables and constants
#########################################

# composite_years = np.arange(2017, 2019)
# site_lon, site_lat = [-105.5464, 	40.0329]


# Site coordinates, date ranges, and save paths
site_info = {
    'US-NR1': {
        'coords': (-105.5464, 40.0329),
        'start': '2017-01-01',
        'end': '2018-12-31'
    },
    'OSBS': {
        'coords': (-81.993431, 29.689282),
        'start': '2021-01-01',
        'end': '2022-12-31'
    },
    'Ca-Obs': {
        'coords': (-105.1178, 53.9872),
        'start': '2018-01-01',
        'end': '2022-12-31'
    },
    'DEJU': {
        'coords': (-145.75136, 63.88112),
        'start': '2019-01-01',
        'end': '2021-12-31'
    }
}

site_lon = site_info[site_name]['coords'][0]
site_lat = site_info[site_name]['coords'][1]
composite_years = np.arange(int(site_info[site_name]['start'][:4]), int(site_info[site_name]['end'][:4]) + 1)

#########################################
# Begin main
#########################################
#%%
# def main():

# mark start time to keep track of elapsed
start_total = time.time()

def clip_2dcurv_ds_to_point(ds, lon_pt, lat_pt):
    # Find the x, y indices where lon_pt and lat_pt are found in ds
    lon_2d = ds.lon.values
    lat_2d = ds.lat.values

    # Compute the absolute difference and find the indices of the minimum
    dist = np.abs(lon_2d - lon_pt) + np.abs(lat_2d - lat_pt)
    y_idx, x_idx = np.unravel_index(np.argmin(dist), lon_2d.shape)
    lon_selected = ds.lon.isel(x=x_idx, y=y_idx).values
    lat_selected = ds.lat.isel(x=x_idx, y=y_idx).values
    print(f"Nearest point in dataset to ({lon_pt}, {lat_pt}) is at ({lon_selected}, {lat_selected}) with distance {dist[y_idx, x_idx]:.6f}")
    ds_point = ds.isel(x=x_idx, y=y_idx)
    return ds_point

### Load all the MCD19 data



MCD19_QC1_arr = []
MCD19_QC2_arr = []
MCD19_QC3_arr = []
MCD19_QC4_arr = []
MOD13_arr = []
MCD43_arr = []
composite_year = 2015
for composite_year in composite_years:
    print(f"Loading MCD19 year {composite_year}...")

    composite_nn = 12
    for composite_nn in range(0, 23):
        print(f"  composite {composite_nn:02d}...")

        # List all files for this month portion
        # e.g. MCD19A1.h09v05.061_1km_16day_CV-MVC_QCfilt_CloudFree_AllAOD_AllAdj_2025-21.nc
        MCD19A1_QC1_files = glob.glob(f'{MCD19_dir_QC1}MCD19A1.{MODIS_tile}.*_{composite_year}-{composite_nn:02d}.nc')
        MCD19A1_QC2_files = glob.glob(f'{MCD19_dir_QC2}MCD19A1.{MODIS_tile}.*_{composite_year}-{composite_nn:02d}.nc')
        MCD19A1_QC3_files = glob.glob(f'{MCD19_dir_QC3}MCD19A1.{MODIS_tile}.*_{composite_year}-{composite_nn:02d}.nc')
        MCD19A1_QC4_files = glob.glob(f'{MCD19_dir_QC4}MCD19A1.{MODIS_tile}.*_{composite_year}-{composite_nn:02d}.nc')

        if len(MCD19A1_QC1_files) > 0:
            MCD19A1_QC1_file = MCD19A1_QC1_files[0]  # Assuming there's only one file per month portion
            MCD19A1_QC1_ds_curv = xr.open_dataset(MCD19A1_QC1_file)
            MCD19A1_QC1_ds_pt = clip_2dcurv_ds_to_point(MCD19A1_QC1_ds_curv, site_lon, site_lat)
            MCD19_QC1_arr.append(MCD19A1_QC1_ds_pt)
        else:
            print(f"No files for {composite_year}-{composite_nn:02d} in {MCD19_dir_QC1}")
            
        if len(MCD19A1_QC2_files) > 0:
            MCD19A1_QC2_file = MCD19A1_QC2_files[0]  # Assuming there's only one file per month portion
            MCD19A1_QC2_ds_curv = xr.open_dataset(MCD19A1_QC2_file)
            MCD19A1_QC2_ds_pt = clip_2dcurv_ds_to_point(MCD19A1_QC2_ds_curv, site_lon, site_lat)
            MCD19_QC2_arr.append(MCD19A1_QC2_ds_pt)
        else:
            print(f"No files for {composite_year}-{composite_nn:02d} in {MCD19_dir_QC2}")

        if len(MCD19A1_QC3_files) > 0:
            MCD19A1_QC3_file = MCD19A1_QC3_files[0]  # Assuming there's only one file per month portion
            MCD19A1_QC3_ds_curv = xr.open_dataset(MCD19A1_QC3_file)
            MCD19A1_QC3_ds_pt = clip_2dcurv_ds_to_point(MCD19A1_QC3_ds_curv, site_lon, site_lat)
            MCD19_QC3_arr.append(MCD19A1_QC3_ds_pt)
        else:
            print(f"No files for {composite_year}-{composite_nn:02d} in {MCD19_dir_QC3}")

        if len(MCD19A1_QC4_files) > 0:
            MCD19A1_QC4_file = MCD19A1_QC4_files[0]  # Assuming there's only one file per month portion
            MCD19A1_QC4_ds_curv = xr.open_dataset(MCD19A1_QC4_file)
            MCD19A1_QC4_ds_pt = clip_2dcurv_ds_to_point(MCD19A1_QC4_ds_curv, site_lon, site_lat)
            MCD19_QC4_arr.append(MCD19A1_QC4_ds_pt)
        else:
            print(f"No files for {composite_year}-{composite_nn:02d} in {MCD19_dir_QC4}")

    
    # print(f"Loading MOD13 year {composite_year}...")
    # MOD13_file = os.path.join(MOD13_dir, f'MOD13A2.061_01d_aid0001_WUS_{composite_year}.nc')
    # MOD13_xr = xr.open_dataset(MOD13_file, decode_coords = 'all').sortby(['x', 'y'], ascending = True)
    # MOD13_xr.rio.write_crs('EPSG:4326', inplace=True)
    # MOD13_xr = MOD13_xr.rename({f'_1_km_16_days_NDVI':'NDVI'})

    # MOD13_xr_site = MOD13_xr.sel(x=site_lon, y=site_lat, method='nearest')
    # MOD13_arr.append(MOD13_xr_site)


    # print(f"Loading MCD43 year {composite_year}...")
    # MCD43_file = os.path.join(MCD43_dir, f'MCD43A4.061_01d_8day_aid0001_WUS_{composite_year}.nc')
    # MCD43_xr = xr.open_dataset(MCD43_file, decode_coords = 'all').sortby(['lon', 'lat'], ascending = True)
    # MCD43_xr.rio.write_crs('EPSG:4326', inplace=True)
    # MCD43_xr_site = MCD43_xr.sel(lon=site_lon, lat=site_lat, method='nearest')
    # MCD43_arr.append(MCD43_xr_site)

MCD19_QC1_pt = xr.concat(MCD19_QC1_arr, dim='time')
MCD19_QC2_pt = xr.concat(MCD19_QC2_arr, dim='time')
MCD19_QC3_pt = xr.concat(MCD19_QC3_arr, dim='time')
MCD19_QC4_pt = xr.concat(MCD19_QC4_arr, dim='time')

all_times = np.union1d(np.union1d(MCD19_QC1_pt.time.values, MCD19_QC2_pt.time.values), np.union1d(MCD19_QC3_pt.time.values, MCD19_QC4_pt.time.values))
MCD19_QC1_pt = MCD19_QC1_pt.reindex(time=all_times)
MCD19_QC2_pt = MCD19_QC2_pt.reindex(time=all_times)
MCD19_QC3_pt = MCD19_QC3_pt.reindex(time=all_times)
MCD19_QC4_pt = MCD19_QC4_pt.reindex(time=all_times)

# MOD13_pt = xr.concat(MOD13_arr, dim='time')
# MCD43_pt = xr.concat(MCD43_arr, dim='time')

## Compute CCI from MCD19
MCD19_QC1_pt = MCD19_QC1_pt.assign(CCI = (MCD19_QC1_pt.Sur_refl11 - MCD19_QC1_pt.Sur_refl1) / (MCD19_QC1_pt.Sur_refl11 + MCD19_QC1_pt.Sur_refl1))
MCD19_QC2_pt = MCD19_QC2_pt.assign(CCI = (MCD19_QC2_pt.Sur_refl11 - MCD19_QC2_pt.Sur_refl1) / (MCD19_QC2_pt.Sur_refl11 + MCD19_QC2_pt.Sur_refl1))
MCD19_QC3_pt = MCD19_QC3_pt.assign(CCI = (MCD19_QC3_pt.Sur_refl11 - MCD19_QC3_pt.Sur_refl1) / (MCD19_QC3_pt.Sur_refl11 + MCD19_QC3_pt.Sur_refl1))
MCD19_QC4_pt = MCD19_QC4_pt.assign(CCI = (MCD19_QC4_pt.Sur_refl11 - MCD19_QC4_pt.Sur_refl1) / (MCD19_QC4_pt.Sur_refl11 + MCD19_QC4_pt.Sur_refl1))

## Compute NDVI from MCD19
MCD19_QC1_pt = MCD19_QC1_pt.assign(NDVI = (MCD19_QC1_pt.Sur_refl2 - MCD19_QC1_pt.Sur_refl1) / (MCD19_QC1_pt.Sur_refl2 + MCD19_QC1_pt.Sur_refl1))
MCD19_QC2_pt = MCD19_QC2_pt.assign(NDVI = (MCD19_QC2_pt.Sur_refl2 - MCD19_QC2_pt.Sur_refl1) / (MCD19_QC2_pt.Sur_refl2 + MCD19_QC2_pt.Sur_refl1))
MCD19_QC3_pt = MCD19_QC3_pt.assign(NDVI = (MCD19_QC3_pt.Sur_refl2 - MCD19_QC3_pt.Sur_refl1) / (MCD19_QC3_pt.Sur_refl2 + MCD19_QC3_pt.Sur_refl1))
MCD19_QC4_pt = MCD19_QC4_pt.assign(NDVI = (MCD19_QC4_pt.Sur_refl2 - MCD19_QC4_pt.Sur_refl1) / (MCD19_QC4_pt.Sur_refl2 + MCD19_QC4_pt.Sur_refl1))

# save data to temp
temp_dat_dir = '/uufs/chpc.utah.edu/common/home/lin-group19/ltk/MODIS/CCI/data/temp'
MCD19_QC1_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC1_descr}_{site_name}.nc')
MCD19_QC2_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC2_descr}_{site_name}.nc')
MCD19_QC3_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC3_descr}_{site_name}.nc')
MCD19_QC4_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC4_descr}_{site_name}.nc')
# MOD13_temp_file = os.path.join(temp_dat_dir, f'MOD13_pt_{site_name}.nc')
# MCD43_temp_file = os.path.join(temp_dat_dir, f'MCD43_pt_{site_name}.nc')
MCD19_QC1_pt.to_netcdf(MCD19_QC1_temp_file)
MCD19_QC2_pt.to_netcdf(MCD19_QC2_temp_file)
MCD19_QC3_pt.to_netcdf(MCD19_QC3_temp_file)
MCD19_QC4_pt.to_netcdf(MCD19_QC4_temp_file)
# MOD13_pt.to_netcdf(MOD13_temp_file)
# MCD43_pt.to_netcdf(MCD43_temp_file)

#%%

# If already loaded, just read from temp
temp_dat_dir = '/uufs/chpc.utah.edu/common/home/lin-group19/ltk/MODIS/CCI/data/temp'
MCD19_QC1_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC1_descr}_{site_name}.nc')
MCD19_QC2_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC2_descr}_{site_name}.nc')
MCD19_QC3_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC3_descr}_{site_name}.nc')
MCD19_QC4_temp_file = os.path.join(temp_dat_dir, f'MCD19_QCfilt_{QC4_descr}_{site_name}.nc')
MOD13_temp_file = os.path.join(temp_dat_dir, f'MOD13_pt_{site_name}.nc')
MCD43_temp_file = os.path.join(temp_dat_dir, f'MCD43_pt_{site_name}.nc')
MCD19_QC1_pt = xr.open_dataset(MCD19_QC1_temp_file)
MCD19_QC2_pt = xr.open_dataset(MCD19_QC2_temp_file)
MCD19_QC3_pt = xr.open_dataset(MCD19_QC3_temp_file)
MCD19_QC4_pt = xr.open_dataset(MCD19_QC4_temp_file)
MOD13_pt = xr.open_dataset(MOD13_temp_file)
MCD43_pt = xr.open_dataset(MCD43_temp_file)


#%%

Photospec_df = pd.read_csv(Photospec_file)
print("Photospec_df columns:", Photospec_df.columns.tolist())

# Remove any data from Photospec_df where NDVI is below 0.6
Photospec_df = Photospec_df[Photospec_df['NDVI'] >= 0.6].reset_index(drop=True)
# Convert Photospec timestamps from "M/D/YY HH:MM" format to datetime64
Photospec_times = pd.to_datetime(Photospec_df['Time'], format='%m/%d/%y %H:%M')

# Select MCD19 data within the time range of Photospec data
MCD19_QC1_pt = MCD19_QC1_pt.sel(time=slice(Photospec_times.iloc[0], Photospec_times.iloc[-1]))
MCD19_QC2_pt = MCD19_QC2_pt.sel(time=slice(Photospec_times.iloc[0], Photospec_times.iloc[-1]))
MCD19_QC3_pt = MCD19_QC3_pt.sel(time=slice(Photospec_times.iloc[0], Photospec_times.iloc[-1]))
MCD19_QC4_pt = MCD19_QC4_pt.sel(time=slice(Photospec_times.iloc[0], Photospec_times.iloc[-1]))



MCD19_QC1_times = np.array([np.datetime64(t) for t in MCD19_QC1_pt['time'].values])
MCD19_QC2_times = np.array([np.datetime64(t) for t in MCD19_QC2_pt['time'].values])
MCD19_QC3_times = np.array([np.datetime64(t) for t in MCD19_QC3_pt['time'].values])
MCD19_QC4_times = np.array([np.datetime64(t) for t in MCD19_QC4_pt['time'].values])
MOD13_times = np.array([np.datetime64(t) for t in MOD13_pt['time'].values])
MCD43_times = np.array([np.datetime64(t) for t in MCD43_pt['time'].values])


# # Resample MCD43_df to 8-day resolution
# MCD43_df['date'] = MCD43_times
# MCD43_df_8day = MCD43_pt.set_index('date').resample('8D').mean(numeric_only=True).reset_index()
# MCD43_times_8day = pd.to_datetime(MCD43_df_8day['date'])


# Filter Photospec_df for times between 13:00 and 14:00
mask = (Photospec_times.dt.hour >= 13) & (Photospec_times.dt.hour < 14)
Photospec_df_filtered = Photospec_df[mask].reset_index(drop=True)
Photospec_times_filtered = Photospec_times[mask].reset_index(drop=True)

# Set x-axis to month abbreviations at the start of each month
months = np.arange(1, 13)
month_starts = [pd.Timestamp(f'{composite_years[0]}-{m:02d}-01').dayofyear for m in months]
month_labels = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D']




# %%


# Calculate day of year for MCD19_CloudFree_times and Photospec_times_filtered
mcd19_doy = pd.to_datetime(MCD19_QC1_times).dayofyear
mod13_doy = pd.to_datetime(MOD13_times).dayofyear
mcd43_doy = pd.to_datetime(MCD43_times).dayofyear
photospec_doy = Photospec_times_filtered.dt.dayofyear
# mcd19_qc4_doy = pd.to_datetime(MCD19_QC4_times).dayofyear

# Sort data by day of year so you can plot as lines without weird zigzags
mcd19_doy_sorted = mcd19_doy[np.argsort(mcd19_doy)]
mcd19_QC1_ndvi_sorted = MCD19_QC1_pt['NDVI'].values[np.argsort(mcd19_doy)]
mcd19_QC2_ndvi_sorted = MCD19_QC2_pt['NDVI'].values[np.argsort(mcd19_doy)]
mcd19_QC3_ndvi_sorted = MCD19_QC3_pt['NDVI'].values[np.argsort(mcd19_doy)]
mcd19_QC4_ndvi_sorted = MCD19_QC4_pt['NDVI'].values[np.argsort(mcd19_doy)]

mod13_doy_sorted = mod13_doy[np.argsort(mod13_doy)]
mod13_ndvi_sorted = MOD13_pt['NDVI'].values[np.argsort(mod13_doy)]
mcd43_doy_sorted = mcd43_doy[np.argsort(mcd43_doy)]
mcd43_ndvi_sorted = MCD43_pt['NDVI'].values[np.argsort(mcd43_doy)]

#%%
# Set global matplotlib font sizes for axes and legends
plt.rcParams.update({
   'axes.labelsize': 15,
   'axes.titlesize': 15,
   'xtick.labelsize': 15,
   'ytick.labelsize': 15,
   'legend.fontsize': 13
})


MCD19_QC1_color = '#DC267F'
MCD19_QC2_color = '#FE6100' # 
MCD19_QC3_color = '#BF2665' # #C131BC
MCD19_QC4_color = '#DB830B'
MOD13_color = '#0DA10A'
MCD43_color = '#B5C230'

# Plot shaded regions for winter periods
winter_periods = [
    # Ground snow cover periods
    (pd.Timestamp('2017-09-25'), pd.Timestamp('2018-05-30'))
]
############################################
### QC ANALYSIS DELIVERABLE 1 - CCI time series 
############################################

#%%
# Calculate day of year for MCD19_CloudFree_times and Photospec_times_filtered
mcd19_doy = pd.to_datetime(MCD19_QC1_times).dayofyear
photospec_doy = Photospec_times_filtered.dt.dayofyear

cci_arrays = [
    MCD19_QC1_pt['CCI'].values,
    MCD19_QC2_pt['CCI'].values,
    MCD19_QC3_pt['CCI'].values,
    MCD19_QC4_pt['CCI'].values
]
mcd19_cci_min = np.nanmin(np.concatenate(cci_arrays))
mcd19_cci_max = np.nanmax(np.concatenate(cci_arrays))
mcd19_cci_range = mcd19_cci_max - mcd19_cci_min

fig, ax = plt.subplots(figsize=(7, 5))

for start, end in winter_periods:
    ax.axvspan(start, end, color='lightblue', alpha=0.5)
ax.scatter(Photospec_times_filtered, Photospec_df_filtered['CCI'], color='black', s=10, alpha=0.7, label='Photospec')
ax2 = ax.twinx()

# ax2.plot(MCD19_QC1_times, MCD19_QC1_pt['CCI'].values, color=MCD19_QC1_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax2.plot(MCD19_QC3_times, MCD19_QC3_pt['CCI'].values, color=MCD19_QC3_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax2.plot(MCD19_QC4_times, MCD19_QC4_pt['CCI'].values, color=MCD19_QC4_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax2.plot(MCD19_QC2_times, MCD19_QC2_pt['CCI'].values, color=MCD19_QC2_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)

ax2.set_ylim(mcd19_cci_min - (mcd19_cci_range*0.05), mcd19_cci_max + (mcd19_cci_range*0.05))
ax.yaxis.set_major_formatter(FFmt(lambda y, _: f'{y:.1f}'))
ax2.yaxis.set_major_formatter(FFmt(lambda y, _: f'{y:.1f}'))
ax.set_xlim(Photospec_times_filtered.min() - pd.Timedelta(days=10), Photospec_times_filtered.max() + pd.Timedelta(days=10))
ax.xaxis.set_major_locator(MonthLocator(bymonth=[7, 10], interval=1))
ax.xaxis.set_major_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
ax.xaxis.set_major_formatter(DateFormatter('%b\n%Y'))
ax.set_title('')

# Combine legends using Patch
handles = [
    Patch(color = 'lightblue', label=f'Estimated snow cover period', alpha=0.3),
    plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='black', markersize=8, label='PhotoSpec'),
    # plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=MOD13_color, markersize=8, label=f'MOD13'),
    # plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=MCD43_color, markersize=8, label=f'MCD43 (NBAR)'),
    # plt.Line2D([0], [0], color=MCD19_QC1_color, linewidth=2, label=f'MCD19 ({QC1_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC2_color, linewidth=2, label=f'MCD19 ({QC2_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC3_color, linewidth=2, label=f'MCD19 ({QC3_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC4_color, linewidth=2, label=f'MCD19 ({QC4_descr})')
]
ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5, -0.5), fontsize=10, ncol=1)
plt.subplots_adjust(bottom=0.35)

plt.tight_layout()
plt.show()

# plot_filename = os.path.join(plot_dir, f'MCD19_v_PhotoSpec_timeseries_{out_stats_descr}_CCI_{site_name}.png')
# plt.savefig(plot_filename, dpi=150, bbox_inches='tight')
# plt.close()

#%%

############################################
### QC ANALYSIS DELIVERABLE 2 - NDVI time series 
############################################


# Calculate day of year for MCD19_CloudFree_times and Photospec_times_filtered

ndvi_arrays = [
    MCD19_QC1_pt['NDVI'].values,
    MCD19_QC2_pt['NDVI'].values,
    MCD19_QC3_pt['NDVI'].values,
    MCD19_QC4_pt['NDVI'].values
]
mcd19_ndvi_min = np.nanmin(np.concatenate(ndvi_arrays))
mcd19_ndvi_max = np.nanmax(np.concatenate(ndvi_arrays))
mcd19_ndvi_range = mcd19_ndvi_max - mcd19_ndvi_min


fig, ax = plt.subplots(figsize=(7, 5))

for start, end in winter_periods:
    ax.axvspan(start, end, color='lightblue', alpha=0.5)
ax.scatter(Photospec_times_filtered, Photospec_df_filtered['NDVI'], color='black', s=10, alpha=0.7, label='Photospec')
ax2 = ax.twinx()

ax2.scatter(MOD13_times, MOD13_pt['NDVI'].values, color=MOD13_color, s=35, alpha=1, label='MOD13 NDVI', marker='s', edgecolors='black', linewidths=0.5)
ax2.scatter(MCD43_times, MCD43_pt['NDVI'].values, color=MCD43_color, s=35, alpha=1, label='MCD43 NDVI', marker='s', edgecolors='black', linewidths=0.5)

# ax2.plot(MCD19_QC1_times, MCD19_QC1_pt['NDVI'].values, color=MCD19_QC1_color, linewidth=2, alpha=1, label=QC1_descr)

ax2.plot(MCD19_QC3_times, MCD19_QC3_pt['NDVI'].values, color=MCD19_QC3_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax2.plot(MCD19_QC4_times, MCD19_QC4_pt['NDVI'].values, color=MCD19_QC4_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax2.set_ylim(mcd19_ndvi_min - (mcd19_ndvi_range*0.05), mcd19_ndvi_max + (mcd19_ndvi_range*0.05))
ax2.plot(MCD19_QC2_times, MCD19_QC2_pt['NDVI'].values, color=MCD19_QC2_color, marker = 'o', markersize=6, linewidth=3, alpha=1, markeredgecolor='black', markeredgewidth=0.5)
ax.yaxis.set_major_formatter(FFmt(lambda y, _: f'{y:.1f}'))
ax2.yaxis.set_major_formatter(FFmt(lambda y, _: f'{y:.1f}'))
ax.set_xlim(Photospec_times_filtered.min() - pd.Timedelta(days=10), Photospec_times_filtered.max() + pd.Timedelta(days=10))
ax.xaxis.set_major_locator(MonthLocator(bymonth=[7, 10], interval=1))
ax.xaxis.set_major_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
ax.xaxis.set_major_formatter(DateFormatter('%b\n%Y'))
ax.set_title('')

# Combine legends using Patch
handles = [
    Patch(color = 'lightblue', label=f'Estimated snow cover period', alpha=0.3),
    plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='black', markersize=8, label='PhotoSpec'),
    plt.Line2D([0], [0], marker='s', color='w', markerfacecolor=MOD13_color, markersize=8, label=f'MOD13'),
    plt.Line2D([0], [0], marker='s', color='w', markerfacecolor=MCD43_color, markersize=8, label=f'MCD43 (NBAR)'),
    # plt.Line2D([0], [0], color=MCD19_QC1_color, linewidth=2, label=f'MCD19 ({QC1_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC2_color, linewidth=2, label=f'MCD19 ({QC2_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC3_color, linewidth=2, label=f'MCD19 ({QC3_descr})'),
    plt.Line2D([0], [0], color=MCD19_QC4_color, linewidth=2, label=f'MCD19 ({QC4_descr})')
]
ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5, -0.3), fontsize=10, ncol=1)
plt.subplots_adjust(bottom=0.35)

plt.tight_layout()
plt.show()





# %%
